
from fastapi import FastAPI, Request, Form
from fastapi.responses import HTMLResponse, RedirectResponse
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates
import sqlite3
from datetime import datetime

app = FastAPI()
app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory="templates")

conn = sqlite3.connect("users.db", check_same_thread=False)
cursor = conn.cursor()
cursor.execute("CREATE TABLE IF NOT EXISTS users (mobile TEXT PRIMARY KEY, password TEXT)")
cursor.execute("CREATE TABLE IF NOT EXISTS logs (mobile TEXT, date TEXT, wake TEXT, sleep TEXT, urges INT, resistance INT, exercise INT, coding INT)")
conn.commit()

@app.get("/", response_class=HTMLResponse)
def root(): return RedirectResponse("/login")

@app.get("/register", response_class=HTMLResponse)
def register_page(request: Request):
    return templates.TemplateResponse("register.html", {"request": request})

@app.post("/register")
def register(mobile: str = Form(...), password: str = Form(...)):
    cursor.execute("INSERT OR REPLACE INTO users VALUES (?, ?)", (mobile, password))
    conn.commit()
    return RedirectResponse("/login", status_code=302)

@app.get("/login", response_class=HTMLResponse)
def login_page(request: Request):
    return templates.TemplateResponse("login.html", {"request": request})

@app.post("/login")
def login(request: Request, mobile: str = Form(...), password: str = Form(...)):
    cursor.execute("SELECT * FROM users WHERE mobile = ? AND password = ?", (mobile, password))
    user = cursor.fetchone()
    if user:
        response = RedirectResponse("/dashboard", status_code=302)
        response.set_cookie("mobile", mobile)
        return response
    return RedirectResponse("/login", status_code=302)

@app.get("/log", response_class=HTMLResponse)
def log_page(request: Request):
    return templates.TemplateResponse("log.html", {"request": request})

@app.post("/log")
def log(mobile: str = Form(...), wake_time: str = Form(...), sleep_time: str = Form(...),
        urges: int = Form(...), resistance: int = Form(...), exercise: int = Form(...), coding: int = Form(...)):
    date = datetime.now().strftime("%Y-%m-%d")
    cursor.execute("INSERT INTO logs VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                   (mobile, date, wake_time, sleep_time, urges, resistance, exercise, coding))
    conn.commit()
    return RedirectResponse("/dashboard", status_code=302)

@app.get("/dashboard", response_class=HTMLResponse)
def dashboard(request: Request):
    return templates.TemplateResponse("dashboard.html", {"request": request})
